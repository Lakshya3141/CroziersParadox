#!/bin/bash

#### SLURM settings ####
#SBATCH --ntasks=1
#SBATCH --job-name=BaseTransSurv
#SBATCH --output=slurm.%j.out
#SBATCH --time=20:00:00
#SBATCH --mem=1GB
#SBATCH --array=1-270
#SBATCH --partition=regular

module load  R/4.3.2-gfbf-2023a
module load foss/2023a

# Compile the program
g++ -std=c++2a -O2 Random.hpp main.cpp Parameters.hpp Individual.hpp Population.hpp config_parser.h -o myprog

# Check if compilation was successful
if [ $? -ne 0 ]; then
  echo "Compilation failed"
  exit 1
fi

# Ensure the binary has execution permissions
chmod +x myprog

# Print out the architecture of the node
uname -m

# Print out the file type of the binary
file ./myprog

parSet=$SLURM_ARRAY_TASK_ID

# Create directory and copy files
mkdir $parSet  
cd $parSet
cp ../myprog .
cp ../create_sim_script_OldControl.R .
cp ../create_ini.R .

# Run the R script
Rscript create_sim_script_OldControl.R ${parSet}

# Ensure the binary has execution permissions again (in the new directory)
chmod +x myprog

# Run the binary with config.ini
./myprog config.ini
