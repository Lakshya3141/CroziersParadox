# CroziersParadox
 Code for Lakshya's final semester thesis on resolving crozier's paradox
